mhill44 doing 0x04 loops conditions and parsings assignment
